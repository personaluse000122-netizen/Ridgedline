export const pad = {
  keys: new Set        (),
  /** When set, replaces the physical keyboard until the next call. */
  qa: null                      ,
  /** When set, replaces A/D steer. Same sign as production steer (+ is left). */
  steerOverride: null                 ,
  /** Right stick / touch X. −1 is left, +1 is right. */
  axisX: 0,
  /** Touch / stick Y. +1 is forward. */
  axisY: 0,
  mouseFire: false,
  touchFire: false,
  aimX: 0,
  aimY: 0,
  usingPointer: false,
};

export function keyDown(code        )          {
  if (pad.qa) return pad.qa.has(code);
  return pad.keys.has(code);
}

export function bindKeys()             {
  const down = (e               ) => {
    if (pad.qa) return;
    pad.keys.add(e.code);
    if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
  };
  const up = (e               ) => {
    pad.keys.delete(e.code);
  };
  const blur = () => {
    pad.keys.clear();
    pad.mouseFire = false;
  };
  const hide = () => {
    if (document.hidden) {
      pad.keys.clear();
      pad.mouseFire = false;
    }
  };
  window.addEventListener("keydown", down);
  window.addEventListener("keyup", up);
  window.addEventListener("blur", blur);
  document.addEventListener("visibilitychange", hide);
  return () => {
    window.removeEventListener("keydown", down);
    window.removeEventListener("keyup", up);
    window.removeEventListener("blur", blur);
    document.removeEventListener("visibilitychange", hide);
    pad.keys.clear();
    pad.mouseFire = false;
    pad.touchFire = false;
    pad.qa = null;
    pad.steerOverride = null;
    pad.axisX = 0;
    pad.axisY = 0;
  };
}

                
                    
                      
                           
                             
                                     
                                          
      
   
 

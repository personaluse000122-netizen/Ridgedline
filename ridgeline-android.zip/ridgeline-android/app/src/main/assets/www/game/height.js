/** Rolling valley. Pure math so gameplay and the mesh share one surface. */
export const LAKE_X = 36;
export const LAKE_Z = -18;
export const WORLD_LIMIT = 96;

export function heightAt(x        , z        )         {
  const n1 = Math.sin(x * 0.02 + 0.4) * Math.cos(z * 0.017);
  const n2 = Math.sin(x * 0.055 + z * 0.02) * 0.45;
  const n3 = Math.cos(z * 0.031 + 1.2) * Math.sin(x * 0.027);
  let h = n1 * 4.2 + n2 * 2.2 + n3 * 2.6;

  const r = Math.hypot(x * 0.85, z);
  h += (r / 55) * (r / 55) * 6;

  if (r > 72) {
    const t = (r - 72) / 30;
    h += t * t * 32;
  }

  const lr = Math.hypot(x - LAKE_X, z - LAKE_Z);
  if (lr < 24) {
    const t = 1 - lr / 24;
    const s = t * t * (3 - 2 * t);
    h = h * (1 - s) + -3.4 * s;
  }
  return h;
}

export function inLake(x        , z        )          {
  return Math.hypot(x - LAKE_X, z - LAKE_Z) < 11.5 && heightAt(x, z) < -1.15;
}

export function normalAt(
  x        ,
  z        ,
  out                                                    ,
)       {
  const e = 0.75;
  const hL = heightAt(x - e, z);
  const hR = heightAt(x + e, z);
  const hD = heightAt(x, z - e);
  const hU = heightAt(x, z + e);
  const nx = hL - hR;
  const ny = 2 * e;
  const nz = hD - hU;
  const len = Math.hypot(nx, ny, nz) || 1;
  out.set(nx / len, ny / len, nz / len);
}

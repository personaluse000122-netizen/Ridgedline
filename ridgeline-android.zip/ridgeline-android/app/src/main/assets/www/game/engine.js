import * as THREE from "../vendor/three.js";
import { sfx } from "./audio.js";
import { heightAt, inLake, LAKE_X, LAKE_Z, WORLD_LIMIT } from "./height.js";
import { bindKeys, keyDown, pad } from "./input.js";
import { createLandscape,               } from "./terrain.js";

                                             

                   
                
               
               
                 
              
                 
                     
                
                
                 
                 
               
               
               
                  
  

                     
                                            
                            
  

                       
                    
                    
                          
                      
  

const MAG = 18;
const MAX_SPEED = 16;
const TURN = 2.35;
const SAVE_KEY = "ridgeline.v1";

                                           

              
             
                 
            
            
            
              
             
             
                
               
                
                
                  
                     
                                    
  

             
                 
            
            
            
             
             
             
               
                      
              
  

              
                 
            
            
            
             
             
             
               
              
  

                                                                    

function clamp(v        , a        , b        ) {
  return Math.max(a, Math.min(b, v));
}

function damp(cur        , target        , lambda        , dt        ) {
  return cur + (target - cur) * (1 - Math.exp(-lambda * dt));
}

function dampAngle(cur        , target        , lambda        , dt        ) {
  const d = Math.atan2(Math.sin(target - cur), Math.cos(target - cur));
  return cur + d * (1 - Math.exp(-lambda * dt));
}

function loadBest() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return 0;
    const parsed = JSON.parse(raw)                                       ;
    if (parsed.version === 1 && typeof parsed.best === "number") return parsed.best;
  } catch {
    /* ignore quota / private mode */
  }
  return 0;
}

function saveBest(best        ) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify({ version: 1, best }));
  } catch {
    /* ignore */
  }
}

export function startGame(
  canvas                   ,
  mapCanvas                          ,
  hooks       ,
)          {
  const disposables                            = [];
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xdfe6d4, 72, 215);
  scene.background = new THREE.Color(0xd7e6de);

  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 700);
  camera.position.set(18, 14, 32);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
    failIfMajorPerformanceCaveat: false,
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const landscape = createLandscape(scene, disposables);
  const colliders             = landscape.colliders;

  const buggy = buildBuggy(disposables);
  scene.add(buggy.group);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(1.55, 12),
    new THREE.MeshBasicMaterial({ color: "#1c2822", transparent: true, opacity: 0.28, depthWrite: false }),
  );
  shadow.rotation.x = -Math.PI / 2;
  scene.add(shadow);
  disposables.push(shadow.geometry, shadow.material);

  const actors = createActors(scene, disposables);
  const shots = Array.from({ length: 56 }, () => emptyShot());
  const sparks = Array.from({ length: 90 }, () => emptySpark());
  const shotMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshBasicMaterial({ color: "#ffffff" }),
    shots.length,
  );
  const sparkMesh = new THREE.InstancedMesh(
    new THREE.OctahedronGeometry(0.18, 0),
    new THREE.MeshLambertMaterial({ color: "#ffffff", flatShading: true }),
    sparks.length,
  );
  scene.add(shotMesh, sparkMesh);
  disposables.push(shotMesh.geometry, shotMesh.material                  , sparkMesh.geometry, sparkMesh.material                  );

  const kits = createKits(scene, disposables);

  const sim = {
    phase: "menu"         ,
    paused: false,
    x: 0,
    y: 0,
    z: 8,
    yaw: 0.55,
    speed: 0,
    fx: 0,
    fz: -1,
    steer: 0,
    health: 100,
    score: 0,
    best: loadBest(),
    wave: 1,
    mag: MAG,
    reload: 0,
    fireCd: 0,
    combo: 0,
    comboT: 0,
    banner: "",
    bannerT: 0,
    damageT: 0,
    hitT: 0,
    shake: 0,
    invuln: 0,
    between: false,
    betweenT: 0,
    left: 0,
    hot: false,
    snap: false,
    wheelAng: 0,
    dust: 0,
    time: 0,
    reloadLatch: false,
  };
  sim.fx = -Math.sin(sim.yaw);
  sim.fz = -Math.cos(sim.yaw);

  const v0 = new THREE.Vector3();
  const v1 = new THREE.Vector3();
  const v2 = new THREE.Vector3();
  const aim = new THREE.Vector3(0, 2, -10);
  const desired = new THREE.Vector3();
  const look = new THREE.Vector3();
  const dummy = new THREE.Object3D();
  const raycaster = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  const shotColor = new THREE.Color();
  const sparkColor = new THREE.Color("#e7c36a");

  let gpx = 0;
  let gpy = 0;
  let gpFire = false;
  let raf = 0;
  let last = 0;
  let acc = 0;
  let alive = true;
  let baseFov = 60;

  placeMarks();
  for (const a of actors) {
    if (a.kind === "mark") continue;
    a.group.visible = false;
  }

  const unbind = bindKeys();

  const onMove = (e              ) => {
    if (e.pointerType !== "mouse") return;
    const r = canvas.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return;
    pad.aimX = ((e.clientX - r.left) / r.width) * 2 - 1;
    pad.aimY = -(((e.clientY - r.top) / r.height) * 2 - 1);
    pad.usingPointer = true;
  };
  const onDown = (e              ) => {
    if (e.pointerType !== "mouse" || e.button !== 0) return;
    if (sim.phase !== "play" || sim.paused) return;
    pad.mouseFire = true;
  };
  const onUp = (e              ) => {
    if (e.pointerType === "mouse") pad.mouseFire = false;
  };
  const onContext = (e       ) => e.preventDefault();
  window.addEventListener("pointermove", onMove);
  canvas.addEventListener("pointerdown", onDown);
  window.addEventListener("pointerup", onUp);
  canvas.addEventListener("contextmenu", onContext);

  const onKey = (e               ) => {
    if (e.code !== "Escape" || e.repeat) return;
    if (sim.phase === "play") {
      e.preventDefault();
      sim.paused = !sim.paused;
    }
  };
  window.addEventListener("keydown", onKey);

  window.__controlsTest = {
    getYaw: () => sim.yaw,
    getSpeed: () => sim.speed,
    setKeys: (codes          ) => {
      pad.qa = new Set(codes);
    },
    setSteer: (v        ) => {
      pad.steerOverride = v;
    },
  };

  const ro = new ResizeObserver(() => resize());
  ro.observe(canvas);
  resize();
  emitPhase();

  const loop = (now        ) => {
    if (!alive) return;
    raf = requestAnimationFrame(loop);
    if (!last) {
      last = now;
      return;
    }
    const frameDt = Math.min(0.1, (now - last) / 1000);
    last = now;
    readGamepad();
    acc += frameDt;
    const step = 1 / 60;
    let n = 0;
    while (acc >= step && n < 5) {
      tick(step);
      acc -= step;
      n++;
    }
    updateCamera(frameDt, now);
    updateTurret(frameDt);
    landscape.update(sim.time);
    syncInstances();
    drawMap();
    renderer.render(scene, camera);
    hooks.onHud(makeHud());
  };
  raf = requestAnimationFrame(loop);

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    const small = w < 760 || matchMedia("(pointer: coarse)").matches;
    baseFov = small ? 70 : 60;
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, small ? 1.5 : 1.65));
    renderer.setSize(w, h, false);
  }

  function readGamepad() {
    gpx = 0;
    gpy = 0;
    gpFire = false;
    try {
      const list = navigator.getGamepads?.();
      const gp = list && list[0];
      if (!gp) return;
      const ax = gp.axes[0] ?? 0;
      const ay = gp.axes[1] ?? 0;
      if (Math.abs(ax) > 0.18) gpx = ax;
      if (Math.abs(ay) > 0.18) gpy = ay;
      if (gp.buttons[0]?.pressed || gp.buttons[7]?.pressed || gp.buttons[5]?.pressed) gpFire = true;
      const rx = gp.axes[2] ?? 0;
      const ry = gp.axes[3] ?? 0;
      if (Math.abs(rx) > 0.28 || Math.abs(ry) > 0.28) {
        pad.aimX = clamp(rx, -1, 1) * 0.92;
        pad.aimY = clamp(-ry, -1, 1) * 0.62;
        pad.usingPointer = true;
      }
    } catch {
      /* gamepad blocked */
    }
  }

  function tick(dt        ) {
    sim.time += dt;
    const playing = sim.phase === "play" && !sim.paused;
    if (playing) {
      drive(dt);
      combat(dt);
      kitsTick(dt);
      timers(dt);
      waves(dt);
    } else {
      sim.fx = -Math.sin(sim.yaw);
      sim.fz = -Math.cos(sim.yaw);
      sim.wheelAng += dt * 0.5;
      sfx.setEngine(0, 0);
    }
    sim.y = heightAt(sim.x, sim.z);
    placeBuggy();
    placeActors(dt);
    sim.shake *= Math.exp(-6 * dt);
    if (reduce) sim.shake = 0;
  }

  function drive(dt        ) {
    let throttle = 0;
    if (keyDown("KeyW") || keyDown("ArrowUp")) throttle += 1;
    if (keyDown("KeyS") || keyDown("ArrowDown")) throttle -= 1;
    throttle += pad.axisY;
    throttle += -gpy;
    throttle = clamp(throttle, -1, 1);

    if (throttle > 0.05) sim.speed += 22 * throttle * dt;
    else if (throttle < -0.05) sim.speed -= 30 * dt;
    else sim.speed *= Math.exp(-2.4 * dt);
    if (inLake(sim.x, sim.z)) sim.speed *= Math.exp(-2.2 * dt);
    sim.speed = clamp(sim.speed, -7, MAX_SPEED);

    // A / ← increases yaw (nose left on the chase cam). D decreases it.
    let steer = 0;
    if (pad.steerOverride !== null) {
      steer = pad.steerOverride;
    } else {
      if (keyDown("KeyA") || keyDown("ArrowLeft")) steer += 1;
      if (keyDown("KeyD") || keyDown("ArrowRight")) steer -= 1;
      steer -= pad.axisX;
      steer -= gpx;
      steer = clamp(steer, -1, 1);
    }
    sim.steer = steer;
    const reverse = sim.speed >= 0 ? 1 : -1;
    const speedFactor = Math.max(0.72, Math.min(1, Math.abs(sim.speed) / 6));
    sim.yaw += steer * TURN * speedFactor * reverse * dt;
    sim.fx = -Math.sin(sim.yaw);
    sim.fz = -Math.cos(sim.yaw);
    sim.x += sim.fx * sim.speed * dt;
    sim.z += sim.fz * sim.speed * dt;

    const ahead = heightAt(sim.x + sim.fx * 1.2, sim.z + sim.fz * 1.2) - heightAt(sim.x, sim.z);
    if (ahead > 0.55 && sim.speed > 0) sim.speed *= Math.exp(-ahead * 2.5 * dt);

    const rr = Math.hypot(sim.x, sim.z);
    if (rr > WORLD_LIMIT) {
      sim.x *= WORLD_LIMIT / rr;
      sim.z *= WORLD_LIMIT / rr;
      const ox = sim.x / WORLD_LIMIT;
      const oz = sim.z / WORLD_LIMIT;
      if (sim.speed > 0 && sim.fx * ox + sim.fz * oz > 0.25) sim.speed *= 0.9;
    }

    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const dx = sim.x - c.x;
      const dz = sim.z - c.z;
      const min = c.r + 0.95;
      const d2 = dx * dx + dz * dz;
      if (d2 < min * min && d2 > 1e-6) {
        const d = Math.sqrt(d2);
        const push = (min - d) / d;
        sim.x += dx * push;
        sim.z += dz * push;
        sim.speed *= 0.985;
      }
    }

    sim.wheelAng += sim.speed * dt * 1.6;
    sfx.setEngine(sim.speed, throttle);

    if (Math.abs(sim.speed) > 8) {
      sim.dust -= dt;
      if (sim.dust <= 0) {
        sim.dust = 0.045;
        burst(sim.x - sim.fx * 1.1, sim.y + 0.15, sim.z - sim.fz * 1.1, 1, 2.5);
      }
    }
  }

  function combat(dt        ) {
    if (sim.reload > 0) {
      sim.reload -= dt;
      if (sim.reload <= 0) {
        sim.reload = 0;
        sim.mag = MAG;
      }
    }
    if (sim.fireCd > 0) sim.fireCd -= dt;

    const wantReload = keyDown("KeyR");
    if (wantReload && !sim.reloadLatch && sim.mag < MAG && sim.reload <= 0) {
      sim.reload = 1.15;
    }
    sim.reloadLatch = wantReload;

    const wantFire = pad.mouseFire || pad.touchFire || gpFire || keyDown("Space");
    if (wantFire && sim.fireCd <= 0 && sim.reload <= 0 && sim.mag > 0) {
      firePlayer();
    }

    for (let i = 0; i < shots.length; i++) {
      const s = shots[i];
      if (!s.alive) continue;
      s.life -= dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.z += s.vz * dt;
      if (s.life <= 0 || s.y < heightAt(s.x, s.z) + 0.05) {
        if (s.life > 0) burst(s.x, Math.max(s.y, heightAt(s.x, s.z) + 0.1), s.z, 4, 4);
        s.alive = false;
        continue;
      }
      if (s.fromPlayer) {
        for (let a = 0; a < actors.length; a++) {
          const actor = actors[a];
          if (!actor.alive) continue;
          const rad = actor.kind === "skimmer" ? 1.05 : actor.kind === "mark" ? 1.2 : 1.15;
          const cy = actor.y + (actor.kind === "mark" ? 1.15 : actor.kind === "skimmer" ? 0.15 : 0.5);
          const dx = s.x - actor.x;
          const dy = s.y - cy;
          const dz = s.z - actor.z;
          if (dx * dx + dy * dy + dz * dz < rad * rad) {
            s.alive = false;
            actor.hp -= s.dmg;
            actor.flash = 0.14;
            burst(s.x, s.y, s.z, 6, 6);
            sfx.hit();
            sim.hitT = 0.12;
            if (!reduce) sim.shake = Math.min(0.35, sim.shake + 0.05);
            if (actor.hp <= 0) kill(actor);
            break;
          }
        }
      } else {
        const dx = s.x - sim.x;
        const dy = s.y - (sim.y + 0.85);
        const dz = s.z - sim.z;
        if (dx * dx + dy * dy + dz * dz < 1.15 * 1.15) {
          s.alive = false;
          hurt(s.dmg);
        }
      }
    }

    for (let i = 0; i < actors.length; i++) {
      const a = actors[i];
      if (a.kind === "mark") {
        if (!a.alive) {
          a.respawn -= dt;
          if (a.respawn <= 0) reviveMark(a);
        }
        continue;
      }
      if (!a.alive) continue;
      const dx = sim.x - a.x;
      const dz = sim.z - a.z;
      const dist = Math.hypot(dx, dz) || 0.001;
      const nx = dx / dist;
      const nz = dz / dist;
      if (a.kind === "stalker") {
        const sp = 4.1 + sim.wave * 0.26;
        if (dist > 1.7) {
          a.x += nx * sp * dt;
          a.z += nz * sp * dt;
        }
        separate(a, i);
        shove(a);
        if (inLake(a.x, a.z)) {
          a.x -= nx * 3 * dt;
          a.z -= nz * 3 * dt;
        }
        a.y = heightAt(a.x, a.z);
        a.yaw = Math.atan2(nx, nz);
        if (dist < 2.15) {
          a.cd -= dt;
          if (a.cd <= 0) {
            hurt(14);
            a.cd = 0.92;
          }
        }
      } else {
        const sp = 6.2 + sim.wave * 0.32;
        let mx = nx;
        let mz = nz;
        if (dist < 13) {
          mx = -nx;
          mz = -nz;
        } else if (dist < 28) {
          const side = Math.sin(sim.time * 0.85 + a.seed);
          mx = -nz * side;
          mz = nx * side;
        }
        a.x += mx * sp * dt;
        a.z += mz * sp * dt;
        const rr = Math.hypot(a.x, a.z);
        if (rr > WORLD_LIMIT - 2) {
          a.x *= (WORLD_LIMIT - 2) / rr;
          a.z *= (WORLD_LIMIT - 2) / rr;
        }
        a.y = heightAt(a.x, a.z) + 6.1 + Math.sin(sim.time * 2.2 + a.seed) * 0.55;
        a.yaw = Math.atan2(nx, nz);
        a.cd -= dt;
        if (a.cd <= 0 && dist < 38 && dist > 6) {
          enemyShot(a);
          a.cd = Math.max(1.05, 2.2 - sim.wave * 0.08);
        }
      }
      a.flash = Math.max(0, a.flash - dt);
    }
  }

  function separate(a       , index        ) {
    for (let j = 0; j < actors.length; j++) {
      if (j === index) continue;
      const b = actors[j];
      if (!b.alive || b.kind === "mark") continue;
      const dx = a.x - b.x;
      const dz = a.z - b.z;
      const d = Math.hypot(dx, dz);
      if (d < 1.4 && d > 0.001) {
        a.x += (dx / d) * (1.4 - d) * 0.5;
        a.z += (dz / d) * (1.4 - d) * 0.5;
      }
    }
  }

  function shove(a       ) {
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const dx = a.x - c.x;
      const dz = a.z - c.z;
      const min = c.r + 0.55;
      const d = Math.hypot(dx, dz);
      if (d < min && d > 0.001) {
        a.x += (dx / d) * (min - d);
        a.z += (dz / d) * (min - d);
      }
    }
  }

  function kitsTick(dt        ) {
    for (let i = 0; i < kits.length; i++) {
      const k = kits[i];
      if (k.wait > 0) {
        k.wait -= dt;
        k.mesh.visible = false;
        continue;
      }
      k.mesh.visible = true;
      const y = heightAt(k.x, k.z);
      k.mesh.position.set(k.x, y + 0.85 + Math.sin(sim.time * 2 + i) * 0.12, k.z);
      k.mesh.rotation.y += dt * 1.4;
      const dx = sim.x - k.x;
      const dz = sim.z - k.z;
      if (dx * dx + dz * dz < 2.3 * 2.3 && sim.health < 100 && sim.health > 0) {
        sim.health = Math.min(100, sim.health + 32);
        k.wait = 14;
        k.mesh.visible = false;
        sfx.heal();
        burst(k.x, y + 0.8, k.z, 8, 5);
      }
    }
  }

  function timers(dt        ) {
    if (sim.comboT > 0) {
      sim.comboT -= dt;
      if (sim.comboT <= 0) sim.combo = 0;
    }
    if (sim.bannerT > 0) {
      sim.bannerT -= dt;
      if (sim.bannerT <= 0 && !sim.paused) sim.banner = "";
    }
    sim.damageT = Math.max(0, sim.damageT - dt);
    sim.hitT = Math.max(0, sim.hitT - dt);
    sim.invuln = Math.max(0, sim.invuln - dt);
    if (sim.paused) sim.banner = "Paused";
  }

  function waves(dt        ) {
    let left = 0;
    for (let i = 0; i < actors.length; i++) {
      const a = actors[i];
      if (a.alive && a.kind !== "mark") left++;
    }
    sim.left = left;
    if (sim.between) {
      sim.betweenT -= dt;
      if (sim.betweenT <= 0) {
        sim.between = false;
        sim.wave += 1;
        sim.invuln = Math.max(sim.invuln, 0.7);
        spawnWave(sim.wave);
      }
      return;
    }
    if (left === 0 && sim.phase === "play") {
      sim.between = true;
      sim.betweenT = 2.15;
      grant(200 * sim.wave);
      sim.banner = "Ridge clear";
      sim.bannerT = 2;
      sfx.wave();
    }
  }

  function firePlayer() {
    buggy.muzzle.getWorldPosition(v0);
    v1.copy(aim).sub(v0);
    if (v1.lengthSq() < 2) v1.set(sim.fx, 0.04, sim.fz);
    v1.normalize();
    const spread = 0.012 + Math.min(0.02, Math.abs(sim.speed) * 0.0008);
    v1.x += (Math.random() - 0.5) * spread;
    v1.y += (Math.random() - 0.5) * spread;
    v1.z += (Math.random() - 0.5) * spread;
    v1.normalize();
    spawnShot(v0.x, v0.y, v0.z, v1.x, v1.y, v1.z, true, 1, 105);
    sim.mag -= 1;
    sim.fireCd = 0.11;
    buggy.flash.visible = true;
    buggy.flashT = 0.045;
    if (!reduce) sim.shake = Math.min(0.28, sim.shake + 0.03);
    sfx.shot();
    if (sim.mag <= 0) sim.reload = 1.2;
  }

  function enemyShot(a       ) {
    const tx = sim.x + sim.fx * sim.speed * 0.3;
    const ty = sim.y + 0.9;
    const tz = sim.z + sim.fz * sim.speed * 0.3;
    const ox = a.x;
    const oy = a.y;
    const oz = a.z;
    let dx = tx - ox;
    let dy = ty - oy;
    let dz = tz - oz;
    const len = Math.hypot(dx, dy, dz) || 1;
    dx /= len;
    dy /= len;
    dz /= len;
    spawnShot(ox, oy, oz, dx, dy, dz, false, 11, 27);
  }

  function spawnShot(
    x        ,
    y        ,
    z        ,
    dx        ,
    dy        ,
    dz        ,
    fromPlayer         ,
    dmg        ,
    speed        ,
  ) {
    for (let i = 0; i < shots.length; i++) {
      const s = shots[i];
      if (s.alive) continue;
      s.alive = true;
      s.x = x;
      s.y = y;
      s.z = z;
      s.vx = dx * speed;
      s.vy = dy * speed;
      s.vz = dz * speed;
      s.life = fromPlayer ? 1.2 : 2.5;
      s.fromPlayer = fromPlayer;
      s.dmg = dmg;
      return;
    }
  }

  function kill(a       ) {
    a.alive = false;
    a.group.visible = false;
    burst(a.x, a.y + 0.7, a.z, 12, 7);
    sfx.boom();
    if (!reduce) sim.shake = Math.min(0.5, sim.shake + 0.12);
    if (a.kind === "mark") {
      grant(50);
      a.respawn = 8;
    } else {
      grant(a.kind === "skimmer" ? 160 : 100);
    }
  }

  function grant(base        ) {
    if (sim.comboT > 0) sim.combo += 1;
    else sim.combo = 1;
    sim.comboT = 2.5;
    sim.score += base * sim.combo;
    if (sim.score > sim.best) {
      sim.best = sim.score;
      saveBest(sim.best);
    }
  }

  function hurt(amount        ) {
    if (sim.invuln > 0 || sim.phase !== "play") return;
    sim.health -= amount;
    sim.invuln = 0.48;
    sim.damageT = 0.45;
    if (!reduce) sim.shake = Math.min(0.7, sim.shake + 0.24);
    sfx.hurt();
    if (sim.health <= 0) {
      sim.health = 0;
      die();
    }
  }

  function die() {
    sim.phase = "dead";
    sim.paused = false;
    sim.speed = 0;
    sim.banner = "";
    sfx.setEngine(0, 0);
    sfx.boom();
    saveBest(sim.best);
    emitPhase();
  }

  function burst(x        , y        , z        , count        , power        ) {
    let left = count;
    for (let i = 0; i < sparks.length && left > 0; i++) {
      const p = sparks[i];
      if (p.alive) continue;
      p.alive = true;
      p.x = x;
      p.y = y;
      p.z = z;
      p.vx = (Math.random() - 0.5) * power;
      p.vy = Math.random() * power * 0.8;
      p.vz = (Math.random() - 0.5) * power;
      p.max = 0.35 + Math.random() * 0.35;
      p.life = p.max;
      left--;
    }
  }

  function sparksIntegrate(dt        ) {
    for (let i = 0; i < sparks.length; i++) {
      const p = sparks[i];
      if (!p.alive) continue;
      p.life -= dt;
      p.vy -= 12 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      if (p.life <= 0 || p.y < heightAt(p.x, p.z)) p.alive = false;
    }
  }

  function placeBuggy() {
    const h = heightAt(sim.x, sim.z);
    sim.y = h;
    buggy.group.position.set(sim.x, h, sim.z);
    const fx = sim.fx;
    const fz = sim.fz;
    const rx = Math.cos(sim.yaw);
    const rz = -Math.sin(sim.yaw);
    const pitch = Math.atan2(
      heightAt(sim.x - fx, sim.z - fz) - heightAt(sim.x + fx, sim.z + fz),
      2,
    );
    const roll = Math.atan2(
      heightAt(sim.x - rx, sim.z - rz) - heightAt(sim.x + rx, sim.z + rz),
      2,
    );
    buggy.group.rotation.order = "YXZ";
    buggy.group.rotation.y = sim.yaw;
    buggy.group.rotation.x = pitch;
    buggy.group.rotation.z = roll * 0.85 - sim.steer * 0.07 * Math.min(1, Math.abs(sim.speed) / 8);
    for (let i = 0; i < buggy.wheels.length; i++) buggy.wheels[i].rotation.y = sim.wheelAng;
    const flashOn = buggy.flashT > 0;
    buggy.flash.visible = flashOn;
    buggy.flashT = Math.max(0, buggy.flashT - 0.016);
    const blink = sim.invuln > 0 && Math.sin(sim.time * 28) > 0;
    buggy.body.emissiveIntensity = blink ? 0.55 : 0;
    shadow.position.set(sim.x, h + 0.08, sim.z);
    shadow.scale.setScalar(1 + Math.min(0.4, Math.abs(sim.speed) * 0.02));
  }

  function placeActors(dt        ) {
    sparksIntegrate(dt);
    for (let i = 0; i < actors.length; i++) {
      const a = actors[i];
      if (!a.alive) {
        a.group.visible = false;
        continue;
      }
      a.group.visible = true;
      a.group.position.set(a.x, a.y, a.z);
      a.group.rotation.y = a.kind === "mark" ? sim.time * 0.6 + a.seed : a.yaw;
      for (let m = 0; m < a.mats.length; m++) {
        a.mats[m].emissiveIntensity = a.flash > 0 ? 0.85 : a.kind === "skimmer" ? 0.15 : 0;
      }
    }
  }

  function updateCamera(dt        , now        ) {
    if (sim.phase === "menu") {
      const ang = now * 0.00011;
      const cx = Math.sin(ang) * 44 + 6;
      const cz = Math.cos(ang) * 38 - 4;
      const cy = Math.max(heightAt(cx, cz) + 3.5, 13);
      camera.position.set(cx, cy, cz);
      camera.lookAt(12, 2.2, -2);
      const fov = baseFov - 2;
      if (Math.abs(camera.fov - fov) > 0.05) {
        camera.fov = damp(camera.fov, fov, 3, dt);
        camera.updateProjectionMatrix();
      }
      return;
    }
    desired.set(sim.x - sim.fx * 11.2, sim.y + 4.5, sim.z - sim.fz * 11.2);
    const floor = heightAt(desired.x, desired.z) + 1.3;
    if (desired.y < floor) desired.y = floor;
    if (sim.snap) {
      camera.position.copy(desired);
      sim.snap = false;
    } else {
      camera.position.lerp(desired, 1 - Math.exp(-5.2 * dt));
    }
    const camFloor = heightAt(camera.position.x, camera.position.z) + 1.05;
    if (camera.position.y < camFloor) camera.position.y = camFloor;
    if (sim.shake > 0.002) {
      camera.position.x += (Math.random() - 0.5) * sim.shake;
      camera.position.y += (Math.random() - 0.5) * sim.shake * 0.55;
    }
    look.set(sim.x + sim.fx * 5.5, sim.y + 1.35, sim.z + sim.fz * 5.5);
    camera.lookAt(look);
    const fov = baseFov + Math.min(6, Math.abs(sim.speed) * 0.22);
    if (Math.abs(camera.fov - fov) > 0.04) {
      camera.fov = damp(camera.fov, fov, 4, dt);
      camera.updateProjectionMatrix();
    }
  }

  function updateTurret(dt        ) {
    camera.updateMatrixWorld();
    ndc.set(pad.aimX, pad.aimY);
    raycaster.setFromCamera(ndc, camera);
    marchAim(raycaster.ray.origin, raycaster.ray.direction, aim);
    sim.hot = false;
    const origin = raycaster.ray.origin;
    const dir = raycaster.ray.direction;
    for (let i = 0; i < actors.length; i++) {
      const a = actors[i];
      if (!a.alive) continue;
      v1.set(a.x - origin.x, a.y + 0.6 - origin.y, a.z - origin.z);
      const proj = v1.dot(dir);
      if (proj < 1.5 || proj > 95) continue;
      v2.copy(dir).multiplyScalar(proj);
      if (v1.distanceTo(v2) < (a.kind === "skimmer" ? 1.35 : 1.7)) {
        sim.hot = true;
        break;
      }
    }
    if (sim.phase === "menu") return;
    buggy.group.updateMatrixWorld(true);
    v0.copy(aim);
    buggy.group.worldToLocal(v0);
    v0.sub(buggy.turretYaw.position);
    const yaw = Math.atan2(-v0.x, -v0.z);
    buggy.turretYaw.rotation.y = dampAngle(buggy.turretYaw.rotation.y, yaw, 16, dt);
    buggy.turretYaw.updateMatrixWorld(true);
    v1.copy(aim);
    buggy.turretYaw.worldToLocal(v1);
    const pitch = clamp(Math.atan2(v1.y, Math.hypot(v1.x, v1.z) || 1), -0.35, 0.65);
    buggy.turretPitch.rotation.x = damp(buggy.turretPitch.rotation.x, pitch, 16, dt);
  }

  function marchAim(origin               , dir               , out               ) {
    let prevT = 0.4;
    let px = origin.x + dir.x * prevT;
    let py = origin.y + dir.y * prevT;
    let pz = origin.z + dir.z * prevT;
    let prevAbove = py - heightAt(px, pz);
    for (let t = 3; t <= 150; t += 3) {
      const x = origin.x + dir.x * t;
      const y = origin.y + dir.y * t;
      const z = origin.z + dir.z * t;
      const above = y - heightAt(x, z);
      if (above <= 0 && prevAbove > 0) {
        const u = prevAbove / (prevAbove - above || 1);
        const hitT = prevT + (t - prevT) * u;
        out.set(origin.x + dir.x * hitT, origin.y + dir.y * hitT, origin.z + dir.z * hitT);
        return;
      }
      prevT = t;
      prevAbove = above;
      px = x;
      py = y;
      pz = z;
    }
    out.set(origin.x + dir.x * 70, origin.y + dir.y * 70, origin.z + dir.z * 70);
  }

  function syncInstances() {
    for (let i = 0; i < shots.length; i++) {
      const s = shots[i];
      if (!s.alive) {
        dummy.position.set(0, -100, 0);
        dummy.scale.setScalar(0.0001);
        dummy.rotation.set(0, 0, 0);
      } else {
        dummy.position.set(s.x, s.y, s.z);
        dummy.lookAt(s.x + s.vx, s.y + s.vy, s.z + s.vz);
        dummy.scale.set(s.fromPlayer ? 0.12 : 0.2, s.fromPlayer ? 0.12 : 0.2, s.fromPlayer ? 0.85 : 0.4);
        shotColor.set(s.fromPlayer ? "#f2d48a" : "#e07a52");
        shotMesh.setColorAt(i, shotColor);
      }
      dummy.updateMatrix();
      shotMesh.setMatrixAt(i, dummy.matrix);
    }
    shotMesh.instanceMatrix.needsUpdate = true;
    if (shotMesh.instanceColor) shotMesh.instanceColor.needsUpdate = true;

    for (let i = 0; i < sparks.length; i++) {
      const p = sparks[i];
      if (!p.alive) {
        dummy.position.set(0, -100, 0);
        dummy.scale.setScalar(0.0001);
      } else {
        dummy.position.set(p.x, p.y, p.z);
        const k = Math.max(0.15, p.life / p.max);
        dummy.scale.setScalar(k);
        dummy.rotation.set(p.life * 4, p.life * 3, 0);
        sparkColor.set(i % 3 === 0 ? "#e7c36a" : i % 3 === 1 ? "#efe6d2" : "#c4563a");
        sparkMesh.setColorAt(i, sparkColor);
      }
      dummy.updateMatrix();
      sparkMesh.setMatrixAt(i, dummy.matrix);
    }
    sparkMesh.instanceMatrix.needsUpdate = true;
    if (sparkMesh.instanceColor) sparkMesh.instanceColor.needsUpdate = true;
  }

  function drawMap() {
    if (!mapCanvas) return;
    const ctx = mapCanvas.getContext("2d");
    if (!ctx) return;
    const w = mapCanvas.width;
    const h = mapCanvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(28,40,34,0.78)";
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 1, 0, Math.PI * 2);
    ctx.fill();
    const scale = (w / 2 - 12) / 50;
    const rightX = Math.cos(sim.yaw);
    const rightZ = -Math.sin(sim.yaw);
    const blot = (x        , z        , color        , rad        ) => {
      const dx = x - sim.x;
      const dz = z - sim.z;
      const sx = dx * rightX + dz * rightZ;
      const sy = dx * sim.fx + dz * sim.fz;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(w / 2 + sx * scale, h / 2 - sy * scale, rad, 0, Math.PI * 2);
      ctx.fill();
    };
    blot(LAKE_X, LAKE_Z, "#6eb3a8", 7);
    for (let i = 0; i < actors.length; i++) {
      const a = actors[i];
      if (!a.alive) continue;
      blot(a.x, a.z, a.kind === "mark" ? "#e7c36a" : "#c4563a", a.kind === "skimmer" ? 3.5 : 3);
    }
    ctx.fillStyle = "#efe6d2";
    ctx.beginPath();
    ctx.moveTo(w / 2, h / 2 - 7);
    ctx.lineTo(w / 2 + 5, h / 2 + 6);
    ctx.lineTo(w / 2 - 5, h / 2 + 6);
    ctx.closePath();
    ctx.fill();
  }

  function makeHud()      {
    return {
      score: sim.score,
      best: sim.best,
      wave: sim.wave,
      health: sim.health,
      mag: sim.mag,
      magMax: MAG,
      reloading: sim.reload > 0,
      speed: Math.abs(sim.speed),
      combo: sim.comboT > 0 ? sim.combo : 0,
      banner: sim.banner,
      damage: clamp(sim.damageT / 0.45, 0, 1),
      hit: sim.hitT > 0,
      hot: sim.hot,
      left: sim.left,
      paused: sim.paused,
    };
  }

  function emitPhase() {
    hooks.onPhase(sim.phase, makeHud());
  }

  function placeMarks() {
    const spots = [
      [16, 4],
      [-14, 0],
      [6, -16],
      [24, 18],
      [-20, 20],
      [46, -6],
      [-8, -18],
    ];
    let mi = 0;
    for (let s = 0; s < spots.length; s++) {
      const found = findGround(spots[s][0], spots[s][1]);
      if (!found) continue;
      const mark = actors.find((a, idx) => a.kind === "mark" && idx >= mi);
      // pick next mark
      let actor                   ;
      for (let i = 0; i < actors.length; i++) {
        if (actors[i].kind === "mark" && !actors[i].alive && actors[i].homeX === 0 && actors[i].homeZ === 0) {
          actor = actors[i];
          break;
        }
      }
      if (!actor) {
        for (let i = 0; i < actors.length; i++) {
          if (actors[i].kind === "mark" && actors[i].homeX === 0 && actors[i].homeZ === 0) {
            actor = actors[i];
            break;
          }
        }
      }
      if (!actor) break;
      actor.homeX = found.x;
      actor.homeZ = found.z;
      reviveMark(actor);
      mi++;
      void mark;
    }
  }

  function findGround(x        , z        ) {
    for (let i = 0; i < 10; i++) {
      const h = heightAt(x, z);
      if (h > -0.15 && h < 7.5 && !inLake(x, z) && Math.hypot(x, z - 8) > 7) {
        let blocked = false;
        for (let c = 0; c < colliders.length; c++) {
          const col = colliders[c];
          if ((col.x - x) ** 2 + (col.z - z) ** 2 < (col.r + 1.2) ** 2) {
            blocked = true;
            break;
          }
        }
        if (!blocked) return { x, z };
      }
      x += 2.5;
      z += 1.6;
    }
    return null;
  }

  function reviveMark(a       ) {
    a.alive = true;
    a.hp = 1;
    a.respawn = 0;
    a.x = a.homeX;
    a.z = a.homeZ;
    a.y = heightAt(a.homeX, a.homeZ);
    a.group.visible = true;
  }

  function spawnWave(wave        ) {
    const stalkers = Math.min(8, 3 + wave);
    const skimmers = Math.min(5, Math.max(0, wave - 1));
    for (let i = 0; i < stalkers; i++) spawnHostile("stalker");
    for (let i = 0; i < skimmers; i++) spawnHostile("skimmer");
    sim.banner = `Wave ${wave}`;
    sim.bannerT = 1.8;
    let left = 0;
    for (let i = 0; i < actors.length; i++) {
      if (actors[i].alive && actors[i].kind !== "mark") left++;
    }
    sim.left = left;
  }

  function spawnHostile(kind      ) {
    let actor                   ;
    for (let i = 0; i < actors.length; i++) {
      if (actors[i].kind === kind && !actors[i].alive) {
        actor = actors[i];
        break;
      }
    }
    if (!actor) return;
    let x = sim.x;
    let z = sim.z;
    for (let i = 0; i < 14; i++) {
      const ang = Math.random() * Math.PI * 2;
      const dist = 28 + Math.random() * 18;
      x = sim.x + Math.cos(ang) * dist;
      z = sim.z + Math.sin(ang) * dist;
      const rr = Math.hypot(x, z);
      if (rr > 88) {
        x *= 88 / rr;
        z *= 88 / rr;
      }
      const h = heightAt(x, z);
      if (!inLake(x, z) && h > -0.3 && h < 11 && Math.hypot(x - sim.x, z - sim.z) > 20) break;
    }
    actor.alive = true;
    actor.x = x;
    actor.z = z;
    actor.y = heightAt(x, z) + (kind === "skimmer" ? 6 : 0);
    actor.hp = kind === "skimmer" ? 1 + Math.floor(sim.wave / 3) : 2 + Math.floor(sim.wave / 2);
    actor.cd = 0.7 + Math.random() * 1.1;
    actor.flash = 0;
    actor.group.visible = true;
  }

  function resetRound() {
    sim.phase = "play";
    sim.paused = false;
    sim.health = 100;
    sim.score = 0;
    sim.wave = 1;
    sim.mag = MAG;
    sim.reload = 0;
    sim.fireCd = 0;
    sim.speed = 0;
    sim.yaw = 0;
    sim.x = 0;
    sim.z = 8;
    sim.fx = 0;
    sim.fz = -1;
    sim.steer = 0;
    sim.combo = 0;
    sim.comboT = 0;
    sim.invuln = 1.15;
    sim.between = false;
    sim.betweenT = 0;
    sim.damageT = 0;
    sim.snap = true;
    sim.banner = "";
    sim.bannerT = 0;
    for (let i = 0; i < shots.length; i++) shots[i].alive = false;
    for (let i = 0; i < actors.length; i++) {
      const a = actors[i];
      if (a.kind === "mark") {
        if (a.homeX !== 0 || a.homeZ !== 0) reviveMark(a);
      } else {
        a.alive = false;
        a.group.visible = false;
      }
    }
    for (let i = 0; i < kits.length; i++) {
      kits[i].wait = 0;
      kits[i].mesh.visible = true;
    }
    spawnWave(1);
    emitPhase();
  }

  return {
    start() {
      sfx.unlock();
      if (sim.phase === "play") return;
      resetRound();
    },
    again() {
      sfx.unlock();
      resetRound();
    },
    togglePause() {
      if (sim.phase !== "play") return;
      sim.paused = !sim.paused;
      if (!sim.paused && sim.banner === "Paused") sim.banner = "";
    },
    cleanup() {
      alive = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      unbind();
      window.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("contextmenu", onContext);
      window.removeEventListener("keydown", onKey);
      if (window.__controlsTest) delete window.__controlsTest;
      landscape.dispose();
      for (let i = 0; i < disposables.length; i++) disposables[i].dispose();
      renderer.dispose();
    },
  };
}

function emptyShot()       {
  return { alive: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, fromPlayer: false, dmg: 0 };
}

function emptySpark()        {
  return { alive: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, max: 1 };
}

function createKits(scene             , disposables                           )        {
  const geo = new THREE.OctahedronGeometry(0.38, 0);
  const mat = new THREE.MeshLambertMaterial({
    color: "#7dba6e",
    emissive: "#7dba6e",
    emissiveIntensity: 0.35,
    flatShading: true,
  });
  disposables.push(geo, mat);
  const spots = [
    [-10, 18],
    [20, -8],
    [-24, -10],
    [12, 26],
  ];
  const kits        = [];
  for (let i = 0; i < spots.length; i++) {
    const mesh = new THREE.Mesh(geo, mat);
    scene.add(mesh);
    kits.push({ x: spots[i][0], z: spots[i][1], wait: 0, mesh });
  }
  return kits;
}

function createActors(scene             , disposables                           ) {
  const box = (w        , h        , d        ) => {
    const g = new THREE.BoxGeometry(w, h, d);
    disposables.push(g);
    return g;
  };
  const stalkerBody = box(1.15, 0.46, 1.4);
  const stalkerHead = box(0.52, 0.36, 0.48);
  const eyeGeo = box(0.12, 0.1, 0.08);
  const legGeo = box(0.16, 0.28, 0.18);
  const octa = new THREE.OctahedronGeometry(0.66, 0);
  const fin = box(0.85, 0.08, 0.28);
  const pole = new THREE.CylinderGeometry(0.08, 0.1, 1.3, 5);
  const board = box(1.15, 0.9, 0.12);
  const ring = box(0.62, 0.5, 0.14);
  const bull = box(0.26, 0.22, 0.16);
  disposables.push(octa, pole);

  const actors          = [];
  const push = (kind      , group             , mats                             , seed        ) => {
    group.visible = false;
    scene.add(group);
    actors.push({
      kind,
      alive: false,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      hp: 1,
      cd: 0,
      flash: 0,
      seed,
      homeX: 0,
      homeZ: 0,
      respawn: 0,
      group,
      mats,
    });
  };

  for (let i = 0; i < 8; i++) {
    const group = new THREE.Group();
    const bodyMat = lambert("#7a4034");
    const dark = lambert("#1c2822");
    const eye = lambert("#e7c36a", 0.45);
    disposables.push(bodyMat, dark, eye);
    const body = new THREE.Mesh(stalkerBody, bodyMat);
    body.position.y = 0.5;
    const head = new THREE.Mesh(stalkerHead, bodyMat);
    head.position.set(0, 0.8, 0.38);
    const e1 = new THREE.Mesh(eyeGeo, eye);
    e1.position.set(0.15, 0.86, 0.64);
    const e2 = new THREE.Mesh(eyeGeo, eye);
    e2.position.set(-0.15, 0.86, 0.64);
    const legs                     = [
      [-0.4, 0.42],
      [0.4, 0.42],
      [-0.4, -0.42],
      [0.4, -0.42],
    ];
    for (let l = 0; l < legs.length; l++) {
      const leg = new THREE.Mesh(legGeo, dark);
      leg.position.set(legs[l][0], 0.14, legs[l][1]);
      group.add(leg);
    }
    group.add(body, head, e1, e2);
    push("stalker", group, [bodyMat], i * 1.7);
  }

  for (let i = 0; i < 5; i++) {
    const group = new THREE.Group();
    const bodyMat = lambert("#24342e", 0.15);
    const finMat = lambert("#c4563a");
    disposables.push(bodyMat, finMat);
    const core = new THREE.Mesh(octa, bodyMat);
    const f1 = new THREE.Mesh(fin, finMat);
    f1.position.set(0.55, 0, 0);
    const f2 = new THREE.Mesh(fin, finMat);
    f2.position.set(-0.55, 0, 0);
    const f3 = new THREE.Mesh(fin, finMat);
    f3.rotation.y = Math.PI / 2;
    f3.position.set(0, 0, 0.45);
    group.add(core, f1, f2, f3);
    push("skimmer", group, [bodyMat, finMat], i * 2.2);
  }

  for (let i = 0; i < 7; i++) {
    const group = new THREE.Group();
    const wood = lambert("#8a6244");
    const sand = lambert("#efe6d2");
    const clay = lambert("#c4563a");
    const ink = lambert("#1c2822");
    disposables.push(wood, sand, clay, ink);
    const post = new THREE.Mesh(pole, wood);
    post.position.y = 0.65;
    const face = new THREE.Mesh(board, sand);
    face.position.set(0, 1.35, 0);
    const mid = new THREE.Mesh(ring, clay);
    mid.position.set(0, 1.35, 0.02);
    const center = new THREE.Mesh(bull, ink);
    center.position.set(0, 1.35, 0.06);
    group.add(post, face, mid, center);
    push("mark", group, [clay], i);
  }

  return actors;
}

function lambert(color        , emissiveIntensity = 0) {
  return new THREE.MeshLambertMaterial({
    color,
    emissive: color,
    emissiveIntensity,
    flatShading: true,
  });
}

function buildBuggy(disposables                           ) {
  const group = new THREE.Group();
  const clay = lambert("#c4563a");
  const ink = lambert("#1c2822");
  const sand = lambert("#efe6d2");
  const dark = lambert("#2a3330");
  const glass = lambert("#1e3330");
  disposables.push(clay, ink, sand, dark, glass);

  const add = (
    geo                      ,
    mat                ,
    x        ,
    y        ,
    z        ,
  ) => {
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    group.add(mesh);
    disposables.push(geo);
    return mesh;
  };

  add(new THREE.BoxGeometry(1.28, 0.36, 2.3), clay, 0, 0.52, 0.05);
  add(new THREE.BoxGeometry(1.12, 0.2, 0.8), sand, 0, 0.74, -0.55);
  add(new THREE.BoxGeometry(1.02, 0.36, 0.86), glass, 0, 0.9, 0.25);
  add(new THREE.BoxGeometry(1.3, 0.1, 0.16), ink, 0, 0.4, -1.12);
  add(new THREE.BoxGeometry(0.08, 0.5, 0.08), ink, -0.48, 1.05, 0.42);
  add(new THREE.BoxGeometry(0.08, 0.5, 0.08), ink, 0.48, 1.05, 0.42);
  add(new THREE.BoxGeometry(1.04, 0.08, 0.08), ink, 0, 1.28, 0.42);

  const wheelGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.22, 7);
  disposables.push(wheelGeo);
  const wheels               = [];
  const spots                             = [
    [-0.7, 0.32, -0.72],
    [0.7, 0.32, -0.72],
    [-0.7, 0.32, 0.78],
    [0.7, 0.32, 0.78],
  ];
  for (let i = 0; i < spots.length; i++) {
    const pivot = new THREE.Group();
    pivot.position.set(spots[i][0], spots[i][1], spots[i][2]);
    pivot.rotation.z = Math.PI / 2;
    const mesh = new THREE.Mesh(wheelGeo, dark);
    pivot.add(mesh);
    group.add(pivot);
    wheels.push(mesh);
  }

  const turretYaw = new THREE.Group();
  turretYaw.position.set(0, 1.16, -0.08);
  const turretPitch = new THREE.Group();
  turretYaw.add(turretPitch);
  const barrelGeo = new THREE.CylinderGeometry(0.065, 0.09, 1.15, 6);
  const barrel = new THREE.Mesh(barrelGeo, ink);
  barrel.rotation.x = -Math.PI / 2;
  barrel.position.set(0, 0, -0.42);
  turretPitch.add(barrel);
  disposables.push(barrelGeo);
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0, -1.12);
  turretPitch.add(muzzle);
  const flashMat = new THREE.MeshBasicMaterial({ color: "#ffe7a8", transparent: true, opacity: 0.95 });
  const flashGeo = new THREE.ConeGeometry(0.18, 0.36, 6);
  const flash = new THREE.Mesh(flashGeo, flashMat);
  flash.rotation.x = Math.PI / 2;
  flash.visible = false;
  muzzle.add(flash);
  disposables.push(flashGeo, flashMat);
  const house = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.2, 0.42), clay);
  house.position.set(0, 0.02, 0.02);
  turretYaw.add(house);
  disposables.push(house.geometry);
  group.add(turretYaw);

  return { group, turretYaw, turretPitch, muzzle, flash, flashT: 0, wheels, body: clay };
}

import * as THREE from "../vendor/three.js";
import { mergeGeometries } from "../vendor/three.js";
import { LAKE_X, LAKE_Z, heightAt, inLake } from "./height.js";

                                                           

const SIZE = 230;
const SEG = 70;

function rng(seed        ) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function paint(color             , x        , y        , z        , steep        ) {
  const grassA = new THREE.Color("#6f9a62");
  const grassB = new THREE.Color("#4e7a4c");
  const grassC = new THREE.Color("#87a86a");
  const sand = new THREE.Color("#e0cb96");
  const shore = new THREE.Color("#c9b27a");
  const rock = new THREE.Color("#8a847a");
  const rockD = new THREE.Color("#5e645e");
  const snow = new THREE.Color("#f3f0e6");
  const wet = new THREE.Color("#6e8f78");

  const patch = Math.sin(x * 0.17 + z * 0.05) * Math.cos(z * 0.13);
  const lake = Math.hypot(x - LAKE_X, z - LAKE_Z);

  if (y > 18) {
    color.copy(snow).lerp(rock, THREE.MathUtils.clamp((22 - y) / 6, 0, 1));
    return;
  }
  if (steep > 0.42 || y > 12) {
    color.copy(rock).lerp(rockD, THREE.MathUtils.clamp(steep, 0, 1));
    return;
  }
  if (y < -0.6) {
    color.copy(wet);
    return;
  }
  if (lake < 16 && y < 0.8) {
    color.copy(shore).lerp(sand, patch * 0.5 + 0.5);
    return;
  }
  if (y < 0.35) {
    color.copy(sand).lerp(grassA, 0.35);
    return;
  }
  color.copy(grassA).lerp(patch > 0 ? grassC : grassB, Math.abs(patch));
}

function makeTerrain()                       {
  const geo = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG);
  geo.rotateX(-Math.PI / 2);
  const src = geo.attributes.position;
  for (let i = 0; i < src.count; i++) {
    src.setY(i, heightAt(src.getX(i), src.getZ(i)));
  }
  const flat = geo.toNonIndexed();
  geo.dispose();
  const p = flat.attributes.position;
  const colors = new Float32Array(p.count * 3);
  const c = new THREE.Color();
  for (let i = 0; i < p.count; i += 3) {
    const x = (p.getX(i) + p.getX(i + 1) + p.getX(i + 2)) / 3;
    const y = (p.getY(i) + p.getY(i + 1) + p.getY(i + 2)) / 3;
    const z = (p.getZ(i) + p.getZ(i + 1) + p.getZ(i + 2)) / 3;
    const abx = p.getX(i + 1) - p.getX(i);
    const aby = p.getY(i + 1) - p.getY(i);
    const abz = p.getZ(i + 1) - p.getZ(i);
    const acx = p.getX(i + 2) - p.getX(i);
    const acy = p.getY(i + 2) - p.getY(i);
    const acz = p.getZ(i + 2) - p.getZ(i);
    const nx = aby * acz - abz * acy;
    const ny = abz * acx - abx * acz;
    const nz = abx * acy - acx * aby;
    const nl = Math.hypot(nx, ny, nz) || 1;
    paint(c, x, y, z, 1 - Math.abs(ny / nl));
    for (let k = 0; k < 3; k++) {
      colors[(i + k) * 3] = c.r;
      colors[(i + k) * 3 + 1] = c.g;
      colors[(i + k) * 3 + 2] = c.b;
    }
  }
  flat.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  flat.computeVertexNormals();
  return flat;
}

function colored(geo                      , hex        ) {
  const c = new THREE.Color(hex);
  const n = geo.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    arr[i * 3] = c.r;
    arr[i * 3 + 1] = c.g;
    arr[i * 3 + 2] = c.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
  return geo;
}

function makePine() {
  const trunk = colored(new THREE.CylinderGeometry(0.12, 0.18, 0.7, 5), "#5c4636");
  trunk.translate(0, 0.35, 0);
  const a = colored(new THREE.ConeGeometry(1.05, 1.7, 6), "#2f6a45");
  a.translate(0, 1.35, 0);
  const b = colored(new THREE.ConeGeometry(0.72, 1.25, 6), "#3e7d52");
  b.translate(0, 2.25, 0);
  const merged = mergeGeometries([trunk, a, b], false);
  if (!merged) throw new Error("pine merge failed");
  merged.computeVertexNormals();
  return merged;
}

                         
                        
                             
                  
  

export function createLandscape(scene             , disposables                           )            {
  const rand = rng(0x51d6e1);
  const lambert = (extra                                      ) =>
    new THREE.MeshLambertMaterial({ flatShading: true, ...extra });

  const skyGeo = new THREE.SphereGeometry(420, 18, 10);
  const sp = skyGeo.attributes.position;
  const sc = new Float32Array(sp.count * 3);
  const zenith = new THREE.Color("#8eafc4");
  const mid = new THREE.Color("#d7e6df");
  const horizon = new THREE.Color("#f3e4c4");
  const below = new THREE.Color("#cbb992");
  const tmp = new THREE.Color();
  for (let i = 0; i < sp.count; i++) {
    const y = sp.getY(i) / 420;
    if (y > 0.25) tmp.copy(mid).lerp(zenith, Math.min(1, (y - 0.25) / 0.6));
    else if (y > -0.02) tmp.copy(horizon).lerp(mid, (y + 0.02) / 0.27);
    else tmp.copy(below);
    sc[i * 3] = tmp.r;
    sc[i * 3 + 1] = tmp.g;
    sc[i * 3 + 2] = tmp.b;
  }
  skyGeo.setAttribute("color", new THREE.BufferAttribute(sc, 3));
  const sky = new THREE.Mesh(
    skyGeo,
    new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide, fog: false, depthWrite: false }),
  );
  sky.frustumCulled = false;
  sky.renderOrder = -1;
  scene.add(sky);

  const sun = new THREE.Mesh(
    new THREE.CircleGeometry(22, 20),
    new THREE.MeshBasicMaterial({ color: "#f2d78a", fog: false, depthWrite: false }),
  );
  sun.position.set(200, 150, 40);
  sun.lookAt(0, 0, 0);
  scene.add(sun);

  const terrain = new THREE.Mesh(makeTerrain(), lambert({ vertexColors: true }));
  terrain.matrixAutoUpdate = false;
  terrain.updateMatrix();
  scene.add(terrain);

  const waterGeo = new THREE.CircleGeometry(11.2, 8);
  waterGeo.rotateX(-Math.PI / 2);
  const water = new THREE.Mesh(
    waterGeo,
    lambert({ color: "#6eb3a8", transparent: true, opacity: 0.82 }),
  );
  water.position.set(LAKE_X, -1.25, LAKE_Z);
  scene.add(water);

  const pine = makePine();
  const treeMat = lambert({ vertexColors: true });
  const TREE_N = 150;
  const trees = new THREE.InstancedMesh(pine, treeMat, TREE_N);
  const rockGeo = new THREE.IcosahedronGeometry(1, 0);
  const rockMat = lambert({ color: "#ffffff" });
  const ROCK_N = 70;
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, ROCK_N);
  const grassGeo = new THREE.ConeGeometry(0.16, 0.55, 4);
  grassGeo.translate(0, 0.28, 0);
  const grassMat = lambert({ color: "#3f6b45" });
  const GRASS_N = 220;
  const grass = new THREE.InstancedMesh(grassGeo, grassMat, GRASS_N);
  const bloomGeo = new THREE.IcosahedronGeometry(0.16, 0);
  const bloomMat = lambert({ color: "#ffffff" });
  const BLOOM_N = 48;
  const blooms = new THREE.InstancedMesh(bloomGeo, bloomMat, BLOOM_N);

  const colliders             = [];
  const dummy = new THREE.Object3D();
  const treeColor = new THREE.Color();
  const rockColor = new THREE.Color("#9a9286");
  const bloomColor = new THREE.Color();

  let ti = 0;
  let ri = 0;
  let gi = 0;
  let bi = 0;
  for (let n = 0; n < 900 && (ti < TREE_N || ri < ROCK_N || gi < GRASS_N || bi < BLOOM_N); n++) {
    const x = (rand() * 2 - 1) * 100;
    const z = (rand() * 2 - 1) * 100;
    const h = heightAt(x, z);
    if (h < -0.2 || h > 16) continue;
    if (inLake(x, z)) continue;
    if (Math.hypot(x, z - 8) < 16) continue;
    const slopeCheck = Math.abs(heightAt(x + 1, z) - h);
    const roll = rand();
    if (ti < TREE_N && slopeCheck < 0.55 && roll < 0.42 && h > 0.2 && h < 9) {
      const s = 0.75 + rand() * 0.9;
      dummy.position.set(x, h, z);
      dummy.rotation.set(0, rand() * Math.PI * 2, 0);
      dummy.scale.setScalar(s);
      dummy.updateMatrix();
      trees.setMatrixAt(ti, dummy.matrix);
      treeColor.set(rand() > 0.5 ? "#ffffff" : "#d5e6cf");
      trees.setColorAt(ti, treeColor);
      colliders.push({ x, z, r: 0.85 * s });
      ti++;
    } else if (ri < ROCK_N && roll > 0.72) {
      const sx = 0.45 + rand() * 1.5;
      const sy = 0.35 + rand() * 0.9;
      const sz = 0.45 + rand() * 1.4;
      dummy.position.set(x, h - 0.15, z);
      dummy.rotation.set(rand(), rand() * 6, rand());
      dummy.scale.set(sx, sy, sz);
      dummy.updateMatrix();
      rocks.setMatrixAt(ri, dummy.matrix);
      rockColor.set(rand() > 0.6 ? "#6d726c" : "#a39886");
      rocks.setColorAt(ri, rockColor);
      colliders.push({ x, z, r: Math.max(sx, sz) * 0.85 });
      ri++;
    } else if (gi < GRASS_N && h > -0.1 && h < 8) {
      dummy.position.set(x, h, z);
      dummy.rotation.set(0, rand() * 6, 0);
      dummy.scale.set(0.7 + rand(), 0.6 + rand() * 1.1, 0.7 + rand());
      dummy.updateMatrix();
      grass.setMatrixAt(gi, dummy.matrix);
      gi++;
    } else if (bi < BLOOM_N && h > 0.2 && h < 6) {
      dummy.position.set(x, h + 0.15, z);
      dummy.rotation.set(rand(), rand(), rand());
      dummy.scale.setScalar(0.7 + rand());
      dummy.updateMatrix();
      blooms.setMatrixAt(bi, dummy.matrix);
      bloomColor.set(rand() > 0.5 ? "#e7c36a" : "#d4654e");
      blooms.setColorAt(bi, bloomColor);
      bi++;
    }
  }
  trees.count = ti;
  rocks.count = ri;
  grass.count = gi;
  blooms.count = bi;
  if (trees.instanceColor) trees.instanceColor.needsUpdate = true;
  if (rocks.instanceColor) rocks.instanceColor.needsUpdate = true;
  if (blooms.instanceColor) blooms.instanceColor.needsUpdate = true;
  scene.add(trees, rocks, grass, blooms);

  const cloudGeo = new THREE.IcosahedronGeometry(1, 0);
  const cloudMat = lambert({ color: "#f7f4ee" });
  const CLOUDS = 8;
  const clouds = new THREE.InstancedMesh(cloudGeo, cloudMat, CLOUDS);
  const cloudSeeds                                                              = [];
  for (let i = 0; i < CLOUDS; i++) {
    cloudSeeds.push({
      x: (rand() * 2 - 1) * 90,
      y: 22 + rand() * 10,
      z: (rand() * 2 - 1) * 90,
      s: 4 + rand() * 5,
      p: rand() * Math.PI * 2,
    });
  }
  scene.add(clouds);

  const hemi = new THREE.HemisphereLight("#d9f0e6", "#b89a6a", 0.95);
  const sunLight = new THREE.DirectionalLight("#fff1d4", 1.5);
  sunLight.position.set(80, 90, 30);
  scene.add(hemi, sunLight);

  disposables.push(
    skyGeo,
    sky.material                  ,
    sun.geometry,
    sun.material                  ,
    terrain.geometry,
    terrain.material                  ,
    waterGeo,
    water.material                  ,
    pine,
    treeMat,
    rockGeo,
    rockMat,
    grassGeo,
    grassMat,
    bloomGeo,
    bloomMat,
    cloudGeo,
    cloudMat,
  );

  return {
    colliders,
    update(time        ) {
      for (let i = 0; i < CLOUDS; i++) {
        const c = cloudSeeds[i];
        const drift = ((c.x + time * 1.6) % 200) - 100;
        dummy.position.set(drift, c.y + Math.sin(time * 0.15 + c.p) * 0.6, c.z);
        dummy.rotation.set(0.2, time * 0.02 + c.p, 0.1);
        dummy.scale.set(c.s * 1.7, c.s * 0.55, c.s);
        dummy.updateMatrix();
        clouds.setMatrixAt(i, dummy.matrix);
      }
      clouds.instanceMatrix.needsUpdate = true;
      water.position.y = -1.25 + Math.sin(time * 0.8) * 0.05;
    },
    dispose() {},
  };
}

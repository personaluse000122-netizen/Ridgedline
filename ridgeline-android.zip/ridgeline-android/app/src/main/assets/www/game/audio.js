export class Sfx {
  muted = false;
          ctx                      = null;
          master                  = null;
          engineGain                  = null;
          engineOsc                        = null;
          noiseBuf                     = null;

  unlock() {
    const Ctx =
      window.AudioContext ||
      (window                                                           ).webkitAudioContext;
    if (!Ctx) return;
    if (!this.ctx) {
      const ctx = new Ctx();
      this.ctx = ctx;
      const master = ctx.createGain();
      master.gain.value = 0.65;
      master.connect(ctx.destination);
      this.master = master;

      const len = Math.floor(ctx.sampleRate * 0.6);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf;

      const osc = ctx.createOscillator();
      osc.type = "triangle";
      osc.frequency.value = 46;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 280;
      const g = ctx.createGain();
      g.gain.value = 0;
      osc.connect(filter);
      filter.connect(g);
      g.connect(master);
      osc.start();
      this.engineOsc = osc;
      this.engineGain = g;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setEngine(speed        , throttle        ) {
    if (!this.ctx || !this.engineGain || !this.engineOsc) return;
    const t = this.ctx.currentTime;
    const vol = this.muted ? 0 : Math.min(0.16, Math.abs(speed) / 110 + (Math.abs(throttle) > 0.1 ? 0.035 : 0));
    this.engineGain.gain.setTargetAtTime(vol, t, 0.1);
    this.engineOsc.frequency.setTargetAtTime(40 + Math.abs(speed) * 3.4, t, 0.1);
  }

  shot() {
    this.tone(210, 0.08, "square", 0.07);
    this.noise(0.06, 0.1, 1400);
  }

  hit() {
    this.tone(540, 0.06, "triangle", 0.06);
  }

  boom() {
    this.tone(130, 0.16, "sawtooth", 0.07);
    this.noise(0.14, 0.09, 320);
  }

  hurt() {
    this.tone(86, 0.18, "sine", 0.1);
  }

  heal() {
    this.tone(620, 0.09, "sine", 0.05);
    window.setTimeout(() => this.tone(860, 0.1, "sine", 0.045), 70);
  }

  wave() {
    this.tone(392, 0.1, "triangle", 0.06);
    window.setTimeout(() => this.tone(523, 0.1, "triangle", 0.055), 90);
    window.setTimeout(() => this.tone(659, 0.14, "triangle", 0.05), 180);
  }

          tone(freq        , dur        , type                , gain        ) {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(40, freq), t);
    o.frequency.exponentialRampToValueAtTime(Math.max(36, freq * 0.45), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

          noise(dur        , gain        , freq        ) {
    if (!this.ctx || !this.master || !this.noiseBuf || this.muted) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = freq;
    filter.Q.value = 0.7;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.master);
    src.start(t, Math.random() * 0.2);
    src.stop(t + dur + 0.02);
  }
}

export const sfx = new Sfx();

import { sfx } from "./game/audio.js";
import { startGame } from "./game/engine.js";
import { pad } from "./game/input.js";

const $ = (id) => document.getElementById(id);
const el = {
  canvas: $("game"), map: $("map"), hud: $("hud"), hurt: $("hurt"),
  wave: $("wave"), left: $("left"), score: $("score"), health: $("health"),
  healthLabel: $("healthLabel"), mag: $("mag"), magBar: $("magBar"), speed: $("speed"),
  combo: $("combo"), banner: $("banner"), pause: $("pause"), cross: $("cross"), hit: $("hit"),
  card: $("card"), cardEyebrow: $("cardEyebrow"), cardTitle: $("cardTitle"), cardText: $("cardText"),
  keys: $("keys"), go: $("go"), mute: $("mute"), scoreLabel: $("scoreLabel"), scoreVal: $("scoreVal"),
  bestWrap: $("bestWrap"), bestVal: $("bestVal"),
};

let phase = "menu";
let paused = false;
let finalHud = null;

const api = startGame(el.canvas, el.map, {
  onPhase(next, hud) {
    phase = next;
    finalHud = hud;
    renderPhase();
  },
  onHud(h) {
    paused = h.paused;
    el.score.textContent = h.score.toLocaleString();
    el.wave.textContent = `Wave ${h.wave}`;
    el.left.textContent = h.left === 1 ? "1 hostile" : `${h.left} hostiles`;
    el.healthLabel.textContent = String(Math.max(0, Math.round(h.health)));
    el.health.style.width = `${Math.max(0, h.health)}%`;
    el.health.classList.toggle("low", h.health <= 35);
    el.mag.textContent = h.reloading ? "Reloading" : `${h.mag} / ${h.magMax}`;
    el.magBar.style.width = `${(h.mag / h.magMax) * 100}%`;
    el.speed.style.width = `${Math.min(100, (h.speed / 16) * 100)}%`;
    el.combo.textContent = h.combo > 1 ? `x${h.combo}` : "";
    el.banner.textContent = h.banner;
    el.pause.textContent = h.paused ? "Resume" : "Pause";
    el.hurt.style.opacity = String(h.damage * 0.72);
    el.hit.style.opacity = h.hit ? "1" : "0";
    el.cross.classList.toggle("is-hot", h.hot);
    const x = pad.usingPointer ? ((pad.aimX + 1) / 2) * innerWidth : innerWidth / 2;
    const y = pad.usingPointer ? ((1 - pad.aimY) / 2) * innerHeight : innerHeight / 2;
    el.cross.style.left = `${x}px`;
    el.cross.style.top = `${y}px`;
  },
});

function renderPhase() {
  const playing = phase === "play";
  el.hud.classList.toggle("hidden", !playing);
  el.cross.classList.toggle("hidden", !playing);
  const showCard = phase === "menu" || phase === "dead";
  el.card.classList.toggle("hidden", !showCard);
  if (!showCard) return;
  const dead = phase === "dead";
  el.cardEyebrow.textContent = dead ? "Sortie over" : "Valley gun run";
  el.cardTitle.textContent = dead ? "Ridge lost" : "Ridgeline";
  el.cardText.textContent = dead
    ? `The hull gave out on wave ${finalHud?.wave ?? 1}. The valley is still out there.`
    : "A low-poly valley, a scout buggy, and a mounted gun. Turn into the swarm and keep the ridge clear.";
  el.keys.classList.toggle("hidden", dead);
  el.go.textContent = dead ? "Again" : "Start";
  el.scoreLabel.textContent = dead ? "Score" : "Best";
  el.scoreVal.textContent = (dead ? finalHud?.score ?? 0 : finalHud?.best ?? 0).toLocaleString();
  el.bestWrap.classList.toggle("hidden", !dead);
  el.bestVal.textContent = (finalHud?.best ?? 0).toLocaleString();
}

el.go.addEventListener("click", () => {
  sfx.unlock();
  if (phase === "dead") api.again();
  else api.start();
});
el.mute.addEventListener("click", () => {
  sfx.muted = !sfx.muted;
  el.mute.innerHTML = sfx.muted ? "&#128263;" : "&#128266;";
});
el.pause.addEventListener("click", () => api.togglePause());

/* ---- Touch controls ---- */
function capture(elm, id) { try { elm.setPointerCapture(id); } catch { /* pointer already gone */ } }
const stick = $("stick"), knob = $("knob");
function stickMove(e) {
  const r = stick.getBoundingClientRect();
  let dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
  let dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
  const m = Math.hypot(dx, dy);
  if (m > 1) { dx /= m; dy /= m; }
  knob.style.transform = `translate(calc(-50% + ${dx * 38}px), calc(-50% + ${dy * 38}px))`;
  pad.axisX = dx;
  pad.axisY = -dy;
}
function stickEnd() {
  knob.style.transform = "translate(-50%, -50%)";
  pad.axisX = 0;
  pad.axisY = 0;
}
stick.addEventListener("pointerdown", (e) => { capture(stick, e.pointerId); stickMove(e); });
stick.addEventListener("pointermove", (e) => { if (stick.hasPointerCapture?.(e.pointerId)) stickMove(e); });
stick.addEventListener("pointerup", stickEnd);
stick.addEventListener("pointercancel", stickEnd);

function aimFrom(x, y) {
  pad.aimX = (x / innerWidth) * 2 - 1;
  pad.aimY = -(y / innerHeight) * 2 + 1;
  pad.usingPointer = true;
}
const aim = $("aimzone");
aim.addEventListener("pointerdown", (e) => { capture(aim, e.pointerId); aimFrom(e.clientX, e.clientY); });
aim.addEventListener("pointermove", (e) => { if (aim.hasPointerCapture?.(e.pointerId)) aimFrom(e.clientX, e.clientY); });

const fire = $("fire");
fire.addEventListener("pointerdown", (e) => { e.preventDefault(); capture(fire, e.pointerId); pad.touchFire = true; });
const fireOff = () => { pad.touchFire = false; };
fire.addEventListener("pointerup", fireOff);
fire.addEventListener("pointercancel", fireOff);
fire.addEventListener("lostpointercapture", fireOff);

const reload = $("reload");
reload.addEventListener("pointerdown", (e) => { e.preventDefault(); pad.keys.add("KeyR"); });
const reloadOff = () => { pad.keys.delete("KeyR"); };
reload.addEventListener("pointerup", reloadOff);
reload.addEventListener("pointercancel", reloadOff);

/* ---- App lifecycle: auto-pause when backgrounded; Android back button ---- */
function autoPause() {
  if (phase === "play" && !paused) api.togglePause();
  stickEnd();
  pad.touchFire = false;
}
document.addEventListener("visibilitychange", () => { if (document.hidden) autoPause(); });
window.addEventListener("blur", autoPause);
window.__onBack = () => {
  if (phase === "play") { api.togglePause(); return true; }
  return false; // let the native side close the app from menu / game-over
};
window.__onPause = autoPause;

/* Block context menu / pinch-zoom gestures inside the WebView */
document.addEventListener("contextmenu", (e) => e.preventDefault());
document.addEventListener("gesturestart", (e) => e.preventDefault());

renderPhase();

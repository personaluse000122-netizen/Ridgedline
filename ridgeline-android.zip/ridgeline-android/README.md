# Ridgeline – Android app

Ridgeline (the low-poly valley gun-run game) packaged as a native Android app.
It's a full-screen WebView running the game from `app/src/main/assets/www`, so it works
completely **offline** and needs no permissions.

## What's different from the web version
- Native Android project (no React / server / login / database needed to play)
- Landscape, immersive full-screen, screen stays on while playing
- Touch controls always on: left stick drives, drag the right side to aim, **Fire** and **Reload** buttons
- Auto-pauses when you leave the app; the Back button pauses (from the menu it exits)
- Best score saved on the device

## Get an installable APK

### Option A – Android Studio (easiest)
1. Install Android Studio and choose **File ▸ Open…** on this folder. Let Gradle sync.
2. Plug in a phone (USB debugging on) or start an emulator, then press **Run ▶**.
3. For a shareable file: **Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)**.
   The file is `app/build/outputs/apk/debug/app-debug.apk` – copy it to your phone and open it
   (allow "install unknown apps" when asked).

### Option B – Command line
With JDK 17, the Android SDK (platform 34) and Gradle 8.7 installed:
```
gradle assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Option C – No installs: GitHub builds it for you
Push this folder to a GitHub repo. The workflow in `.github/workflows/build-apk.yml` builds the APK;
download it from the **Actions** tab ▸ latest run ▸ **ridgeline-debug-apk**.

## Play-testing in a desktop browser
```
cd app/src/main/assets/www && python3 -m http.server 8080
```
Open http://localhost:8080 (WASD/mouse on desktop, touch UI appears on touch screens).

## Publishing to Google Play
Create a signed release build (Build ▸ Generate Signed Bundle) and bump `versionCode` in `app/build.gradle`.
`store-icon-512.png` is a ready 512×512 store icon.
